import React, { Component } from 'react';
import HamburgerMenu from './HamburgerMenu';
class App extends Component {
    render() {
        return (
            <div>
                <HamburgerMenu/>
            </div>
        );
    }
}

export default App;